x = 5
y = 6
x,y = y,x
print(x)
print(y)