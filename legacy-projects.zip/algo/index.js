let x = 5;
let y = 8;
let z = x;
x = y
y = z
console.log(x);
console.log(y);
