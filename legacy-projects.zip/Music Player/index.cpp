#include <iostream>
using namespace std;

int main(){
    double a = 12E12;
    cout << "Hello world"<<a;
    return 0;
}