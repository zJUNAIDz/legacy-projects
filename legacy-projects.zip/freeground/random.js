// let btn = document.querySelector("#btn");
// let colorName = document.querySelector("#clr_name");
// function run() {
//   setInterval(() => {
//     let r = Math.floor(Math.random() * 255);
//     let g = Math.floor(Math.random() * 255);
//     let b = Math.floor(Math.random() * 255);
//     let a = Math.random()*1;  
//     let colours = `rbga(${r},${g},${b},${a})`;
//     document.bgColor = colours;
//     console.log(colours);
//     colorName.innerHTML = colours;
//   }, 700);
// }
// btn.addEventListener("click", run);

window.status = "hello"