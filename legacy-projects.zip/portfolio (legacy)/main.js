/*function change() {
var p = document.getElementById('p');
setTimeout(()=>{
  p.innerHTML = "Student";
},1000)
setTimeout(()=> {
  p.innerHTML = "Amateur Web Designer"
},2000)
}

var interval;
interval = setInterval(change,3000);*/

var x = prompt();
for( ){
  
}